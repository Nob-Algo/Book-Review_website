<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Fetch authors for selection
$authors = $pdo->query("SELECT * FROM authors ORDER BY name")->fetchAll();
// Fetch categories for selection
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $author_id = $_POST['author_id'] ?? '';
    $published_year = $_POST['published_year'] ?? '';
    $description = $_POST['description'] ?? '';
    $category_ids = $_POST['category_ids'] ?? [];

    $image_name = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $tmpName = $_FILES['image']['tmp_name'];
        $originalName = basename($_FILES['image']['name']);
        $ext = pathinfo($originalName, PATHINFO_EXTENSION);
        $allowed = ['jpg','jpeg','png'];
        if (in_array(strtolower($ext), $allowed)) {
            $image_name = uniqid() . '.' . $ext;
            move_uploaded_file($tmpName, $uploadDir . $image_name);
        } else {
            $message = 'Format gambar tidak didukung.';
        }
    }

    if ($title && $author_id && !$message) {
        $stmt = $pdo->prepare("INSERT INTO books (title, author_id, published_year, description, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $author_id, $published_year ?: null, $description, $image_name]);

        $book_id = $pdo->lastInsertId();

        // Insert into book_categories
        if (!empty($category_ids)) {
            $stmt_cat = $pdo->prepare("INSERT INTO book_categories (book_id, category_id) VALUES (?, ?)");
            foreach ($category_ids as $cat_id) {
                $stmt_cat->execute([$book_id, $cat_id]);
            }
        }

        header('Location: index.php');
        exit;
    } else if (!$message) {
        $message = 'Judul dan Penulis wajib diisi.';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Buku - Book Review</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Tambah Buku</h1>
    <?php if ($message): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST" action="add_book.php" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="title" class="form-label">Judul Buku</label>
            <input type="text" id="title" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="author_id" class="form-label">Penulis</label>
            <select name="author_id" id="author_id" class="form-select" required>
                <option value="">-- Pilih Penulis --</option>
                <?php foreach ($authors as $author): ?>
                <option value="<?= $author['id'] ?>"><?= htmlspecialchars($author['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="published_year" class="form-label">Tahun Terbit</label>
            <input type="number" name="published_year" id="published_year" class="form-control" min="1900" max="2100">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Deskripsi</label>
            <textarea name="description" id="description" cols="30" rows="4" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Cover Gambar (jpg/png)</label>
            <input type="file" name="image" id="image" class="form-control" accept="image/jpeg,image/png" />
        </div>

        <div class="mb-3">
            <label class="form-label">Kategori</label>
            <?php foreach ($categories as $cat): ?>
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="cat<?=$cat['id']?>" name="category_ids[]" value="<?=$cat['id']?>">
                <label for="cat<?=$cat['id']?>" class="form-check-label"><?=htmlspecialchars($cat['name'])?></label>
            </div>
            <?php endforeach; ?>
        </div>

        <button type="submit" class="btn btn-primary">Tambah</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
