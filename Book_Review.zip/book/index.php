<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Proses submit rating via POST
$message_rating = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_id'], $_POST['rating'])) {
    $book_id_post = (int) $_POST['book_id'];
    $rating_post = (int) $_POST['rating'];

    if ($rating_post >=1 && $rating_post <=5) {
        // Cek apakah user sudah memberi rating untuk buku ini
        $stmt_check = $pdo->prepare("SELECT id FROM reviews WHERE book_id = ? AND user_id = ?");
        $stmt_check->execute([$book_id_post, $user_id]);
        $existing_review = $stmt_check->fetch();

        if ($existing_review) {
            // Update rating (kosongkan review_text)
            $stmt_update = $pdo->prepare("UPDATE reviews SET rating = ?, review_text = '', created_at = NOW() WHERE id = ?");
            $stmt_update->execute([$rating_post, $existing_review['id']]);
        } else {
            // Insert rating baru
            $stmt_insert = $pdo->prepare("INSERT INTO reviews (book_id, user_id, rating, review_text) VALUES (?, ?, ?, '')");
            $stmt_insert->execute([$book_id_post, $user_id, $rating_post]);
        }
        // Redirect agar form tidak submit ulang
        header("Location: index.php");
        exit;
    } else {
        $message_rating = "Rating harus antara 1 sampai 5.";
    }
}

// Handle search and filter
$search = $_GET['search'] ?? '';
$filter_category = $_GET['category'] ?? '';

$parameters = [];
$sql = "SELECT b.id, b.title, a.name AS author_name, b.published_year, b.description, b.image,
        (SELECT AVG(rating) FROM reviews r WHERE r.book_id = b.id) AS avg_rating
        FROM books b
        JOIN authors a ON b.author_id = a.id";

if ($filter_category) {
    $sql .= " JOIN book_categories bc ON b.id = bc.book_id
              JOIN categories c ON bc.category_id = c.id
              WHERE c.id = ?";
    $parameters[] = $filter_category;

    if ($search) {
      $sql .= " AND b.title LIKE ?";
      $parameters[] = "%$search%";
    }
} else if ($search) {
    $sql .= " WHERE b.title LIKE ?";
    $parameters[] = "%$search%";
}

$sql .= " ORDER BY b.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($parameters);
$books = $stmt->fetchAll();

// Ambil rating user untuk buku-buku yang ada
$bookIds = array_column($books, 'id');
$userRatings = [];
if ($bookIds) {
    $in_query = implode(',', array_fill(0, count($bookIds), '?'));
    $stmt_user_rating = $pdo->prepare("SELECT book_id, rating FROM reviews WHERE user_id = ? AND book_id IN ($in_query)");
    $stmt_user_rating->execute(array_merge([$user_id], $bookIds));
    $rows = $stmt_user_rating->fetchAll();
    foreach ($rows as $row) {
        $userRatings[$row['book_id']] = $row['rating'];
    }
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

function truncateText($text, $maxChars = 150) {
    if (strlen($text) <= $maxChars) {
        return $text;
    }
    $truncated = substr($text, 0, $maxChars);
    $lastSpace = strrpos($truncated, ' ');
    if ($lastSpace !== false) {
        $truncated = substr($truncated, 0, $lastSpace);
    }
    return $truncated . '...';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Book Review</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .book-image {
        width: 100px;
        height: auto;
        object-fit: contain;
        border: 1px solid #ddd;
        padding: 2px;
        background: #fff;
    }
    .star-rating-static {
        color: gold;
        font-size: 1.1em;
    }
    .star-rating-form label {
        cursor: pointer;
        font-size: 1.2em;
        color: #ccc;
        margin-right: 2px;
    }
    .star-rating-form input[type=radio]:checked ~ label {
        color: gold;
    }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Book Review</a>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <span class="nav-link text-white">Halo, <?=htmlspecialchars($_SESSION['username'])?></span>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Keluar</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">
    <h1>Daftar Buku</h1>
    <?php if ($message_rating): ?>
        <div class="alert alert-danger"><?=htmlspecialchars($message_rating)?></div>
    <?php endif; ?>
    <form class="row g-3 mb-3" method="GET" action="index.php">
        <div class="col-md-5">
            <input type="text" name="search" value="<?=htmlspecialchars($search)?>" class="form-control" placeholder="Cari judul buku...">
        </div>
        <div class="col-md-4">
            <select name="category" class="form-select">
                <option value="">-- Filter Kategori --</option>
                <?php foreach($categories as $cat): ?>
                <option value="<?=$cat['id']?>" <?=($filter_category==$cat['id'])?'selected':''?>><?=htmlspecialchars($cat['name'])?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-primary w-100">Cari & Filter</button>
        </div>
    </form>

    <a href="add_book.php" class="btn btn-success mb-3">Tambah Buku</a>

    <table class="table table-bordered table-striped align-middle">
        <thead>
            <tr>
                <th>Gambar</th>
                <th>Judul</th>
                <th>Penulis</th>
                <th>Tahun Terbit</th>
                <th>Sinopsis</th>
                <th>Rating</th>
                <th>Berikan Rating</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($books) == 0): ?>
            <tr>
                <td colspan="8" class="text-center">Tidak ada data buku.</td>
            </tr>
            <?php else: ?>
            <?php foreach ($books as $book): ?>
            <tr>
                <td>
                    <?php if (!empty($book['image']) && file_exists('uploads/' . $book['image'])): ?>
                        <img src="uploads/<?=htmlspecialchars($book['image'])?>" alt="Cover <?=htmlspecialchars($book['title'])?>" class="book-image">
                    <?php else: ?>
                        <span class="text-muted">Tidak ada gambar</span>
                    <?php endif; ?>
                </td>
                <td><a href="book_detail.php?id=<?= $book['id'] ?>"><?=htmlspecialchars($book['title'])?></a></td>
                <td><?=htmlspecialchars($book['author_name'])?></td>
                <td><?=htmlspecialchars($book['published_year'])?></td>
                <td><?=nl2br(htmlspecialchars(truncateText($book['description'])))?></td>
                <td class="star-rating-static">
                <?php 
                    $avg = round($book['avg_rating'] ?? 0);
                    for ($star=1; $star <=5; $star++): 
                ?>
                    <span><?= $star <= $avg ? '&#9733;' : '&#9734;' ?></span>
                <?php endfor; ?>
                <?= number_format($book['avg_rating'],1) ?>
                </td>
                <td>
                    <form method="POST" action="index.php" class="star-rating-form" style="margin:0;">
                        <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                        <?php
                            $userRating = $userRatings[$book['id']] ?? 0;
                            for ($i=5; $i>=1; $i--):
                        ?>
                        <input type="radio" id="star_<?= $book['id'] ?>_<?= $i ?>" name="rating" value="<?= $i ?>" <?= ($userRating == $i) ? 'checked' : '' ?>>
                        <label for="star_<?= $book['id'] ?>_<?= $i ?>">&#9733;</label>
                        <?php endfor; ?>
                        <button type="submit" class="btn btn-sm btn-primary mt-1">Kirim</button>
                    </form>
                </td>
                <td>
                    <a href="edit_book.php?id=<?=$book['id']?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="delete_book.php?id=<?=$book['id']?>" onclick="return confirm('Yakin ingin menghapus buku ini?')" class="btn btn-sm btn-danger">Hapus</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
