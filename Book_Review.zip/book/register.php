<?php
session_start();
require 'config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (!$username || !$password || !$password_confirm) {
        $message = 'Semua field wajib diisi.';
    } elseif ($password !== $password_confirm) {
        $message = 'Password dan konfirmasi password tidak sama.';
    } else {
        // Cek apakah username sudah terdaftar
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $message = 'Username sudah digunakan, silakan pilih username lain.';
        } else {
            // Buat hash password
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            // Simpan user ke database
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            if ($stmt->execute([$username, $password_hash])) {
                // Registrasi berhasil, redirect ke login
                header('Location: login.php?registered=1');
                exit;
            } else {
                $message = 'Terjadi kesalahan saat menyimpan data.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Register - Book Review</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body class="bg-light">
<div class="container mt-5" style="max-width: 420px;">
    <h3 class="mb-4 text-center">Register Akun Baru</h3>

    <?php if ($message): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST" action="register.php" autocomplete="off">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" id="username" name="username" class="form-control" required autofocus value="<?=htmlspecialchars($_POST['username'] ?? '')?>" />
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" id="password" name="password" class="form-control" required/>
        </div>

        <div class="mb-3">
            <label for="password_confirm" class="form-label">Konfirmasi Password</label>
            <input type="password" id="password_confirm" name="password_confirm" class="form-control" required/>
        </div>

        <button type="submit" class="btn btn-primary w-100">Daftar</button>
    </form>
    
    <p class="text-center mt-3">Sudah punya akun? <a href="login.php">Login di sini</a></p>
</div>
</body>
</html>
