<?php
// Script ini untuk membuat hash password dan memasukkan user ke database

require 'config.php';

// Ganti sesuai username dan password yang ingin dibuat
$username = 'root';
$password_plain = 'admin123';

// Membuat hash dari password
$password_hash = password_hash($password_plain, PASSWORD_DEFAULT);

try {
    // Periksa apakah username sudah ada
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        echo "Username sudah ada, silakan gunakan username lain atau hapus user ini terlebih dahulu.\n";
        exit;
    }

    // Insert user baru ke database
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->execute([$username, $password_hash]);

    echo "User berhasil dibuat:\n";
    echo "Username: $username\n";
    echo "Password: $password_plain\n";
} catch (Exception $e) {
    echo "Terjadi kesalahan: " . $e->getMessage();
}
?>
