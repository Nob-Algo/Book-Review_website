# Book Review Website

## Deskripsi
Website Book Review dengan fitur login, tambah data, edit, hapus, cari, dan filter. Dibangun menggunakan PHP, MySQL, dan Bootstrap.

## Cara Instalasi
1. Import file `book-review-sql.sql` ke database MySQL Anda:

```bash
mysql -u [user] -p < book-review-sql.sql