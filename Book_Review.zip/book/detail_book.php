<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$book_id = $_GET['id'] ?? null;
if (!$book_id) {
    header('Location: index.php');
    exit;
}

// Ambil data buku
$stmt = $pdo->prepare("SELECT b.*, a.name as author_name FROM books b JOIN authors a ON b.author_id = a.id WHERE b.id = ?");
$stmt->execute([$book_id]);
$book = $stmt->fetch();
if (!$book) {
    header('Location: index.php');
    exit;
}

// Ambil rating rata-rata dan jumlah rating
$stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_rating FROM reviews WHERE book_id = ?");
$stmt->execute([$book_id]);
$rating_stats = $stmt->fetch();
$avg_rating = round($rating_stats['avg_rating'] ?? 0, 1);
$total_rating = $rating_stats['total_rating'] ?? 0;

// Cek apakah user sudah memberi rating
$stmt = $pdo->prepare("SELECT rating FROM reviews WHERE book_id = ? AND user_id = ?");
$stmt->execute([$book_id, $_SESSION['user_id']]);
$user_rating = $stmt->fetchColumn();

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = (int) ($_POST['rating'] ?? 0);
    $review_text = trim($_POST['review_text'] ?? '');

    if ($rating >= 1 && $rating <= 5) {
        if ($user_rating !== false) {
            // update rating dan review
            $stmt = $pdo->prepare("UPDATE reviews SET rating = ?, review_text = ?, created_at = NOW() WHERE book_id = ? AND user_id = ?");
            $stmt->execute([$rating, $review_text, $book_id, $_SESSION['user_id']]);
        } else {
            // insert rating dan review baru
            $stmt = $pdo->prepare("INSERT INTO reviews (book_id, user_id, rating, review_text) VALUES (?, ?, ?, ?)");
            $stmt->execute([$book_id, $_SESSION['user_id'], $rating, $review_text]);
        }
        // refresh halaman untuk update rating
        header("Location: book_detail.php?id=$book_id");
        exit;
    } else {
        $message = 'Rating harus antara 1 sampai 5.';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Detail Buku - <?=htmlspecialchars($book['title'])?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        .star-rating {
            font-size: 1.5rem;
            color: gold;
        }
        .star-rating input {
            display: none;
        }
        .star-rating label {
            cursor: pointer;
            color: #ddd;
        }
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label {
            color: gold;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <h2><?=htmlspecialchars($book['title'])?></h2>
    <p><strong>Penulis:</strong> <?=htmlspecialchars($book['author_name'])?></p>
    <p><strong>Tahun Terbit:</strong> <?=htmlspecialchars($book['published_year'])?></p>
    <?php if ($book['image'] && file_exists('uploads/' . $book['image'])): ?>
        <img src="uploads/<?=htmlspecialchars($book['image'])?>" alt="Cover <?=htmlspecialchars($book['title'])?>" style="max-width: 200px;" class="mb-3" />
    <?php endif; ?>
    <p><?=nl2br(htmlspecialchars($book['description']))?></p>

    <h4>Rating Rata-Rata: <?= $avg_rating ?> dari <?= $total_rating ?> penilaian</h4>

    <hr>

    <h4>Berikan Rating & Review Anda</h4>
    <?php if ($message): ?>
        <div class="alert alert-danger"><?=htmlspecialchars($message)?></div>
    <?php endif; ?>
    <form method="POST" action="book_detail.php?id=<?=htmlspecialchars($book_id)?>">
        <div class="star-rating mb-3">
            <?php for ($i=5; $i>=1; $i--): ?>
                <input type="radio" id="star<?=$i?>" name="rating" value="<?=$i?>" <?=($user_rating==$i)?'checked':''?> />
                <label for="star<?=$i?>" title="<?=$i?> stars">&#9733;</label>
            <?php endfor; ?>
        </div>
        <div class="mb-3">
            <label for="review_text" class="form-label">Review</label>
            <textarea name="review_text" id="review_text" rows="4" class="form-control"><?=htmlspecialchars($_POST['review_text'] ?? '')?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Kirim Review</button>
    </form>

    <p class="mt-3"><a href="index.php">Kembali ke Daftar Buku</a></p>
</div>
</body>
</html>
